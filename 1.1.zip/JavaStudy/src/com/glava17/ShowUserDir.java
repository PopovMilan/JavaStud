package com.glava17;

public class ShowUserDir {
    public static void main(String[] args) {
        System.out.println(System.getProperty("user.dir"));
    }
}
