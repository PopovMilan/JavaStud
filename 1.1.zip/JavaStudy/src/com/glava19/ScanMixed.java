package com.glava19;
import java.util.*;
import java.io.*;
public class ScanMixed {
    public static void main(String[] args) throws IOException {
        int i;
        double d;
        boolean �;
        String str;

        FileWriter fout = new FileWriter("test. txt");
        fout.write( "Tec��po�a��e Scanner 10 12.2 ���� true ��� false");
        fout.close();


        FileReader fin = new FileReader ( "Test. txt");

        Scanner src = new Scanner(fin) ;

        while (src. hasNext ())
        {
            if(src. hasNextInt())
            {
                i = src.nextInt();
                System.out.println("int: "+ i);
            }else if(src.hasNextDouble())
            {
                d = src.nextDouble ();
                System.out.println( "dou�e: "+ d) ;
            }else if(src. hasNextBoolean())
            {
                � = src.nextBoolean();
                System.out.println( "boolean : "+ �) ;
            }else
            {
                str = src.next();
                System.out.println("String: "+ str);
            }
        }
    }
}
