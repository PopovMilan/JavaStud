package com.glava2;

public class BlockTest {
    public static void main(String args[]) {
        int x, y=20;
   for (x=0; x<10; x++)
   { System.out.println("��a�e��e �: "+ x);
   System.out.println("��a�e��e �: "+ y);
   y = y - 2;
}
    }
}
