package com.glava2;

public class ForTest {
    public static void main(String args[]) {
        int x;
        for (x = 0; x < 10; x = x + 1) System.out.println("��a�e��e �: " + x);
    }
}