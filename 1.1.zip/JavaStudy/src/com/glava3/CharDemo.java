package com.glava3;

public class CharDemo {
    public static void main(String args[]) {
        char chl, ch2;
        chl = 88; // ��� ������� �
        ch2 = '�';
        System.out.print("chl � ch2: ");
        System.out.println(chl + " " + ch2);
    }
}