package Chapter9.Access_protection.p2;

public class Demo {
    public static void main(String[] args) {
        Protection2 ob1 = new Protection2();
        OtherPackege ob2 = new OtherPackege();
    }
}
