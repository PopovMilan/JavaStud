package Chapter9.Application;

public interface IntStack {
    void push(int item);
    int pop();
}
