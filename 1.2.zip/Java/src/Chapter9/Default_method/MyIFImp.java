package Chapter9.Default_method;

public class MyIFImp  implements  MyIF{
    public int getNumber() {
        return 100;
    }
}
