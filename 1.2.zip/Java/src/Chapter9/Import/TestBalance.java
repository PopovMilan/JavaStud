package Chapter9.Import;

import Chapter9.Import.MyPack.*;

public class TestBalance {
    public static void main(String[] args) {
        Balance test = new Balance("J. J. Jaspers", 99.88);
        test.show();
    }
}
