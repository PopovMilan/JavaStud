package Chapter9.Interface;

public interface Callback {
    void callback(int param);
}
